package com.arty.cache.fake

import com.arty.data.model.BookRatingEntity
import com.arty.domain.model.BookRating

object RatingFactory {

    fun makeRatingEntity(): BookRatingEntity {
        return BookRatingEntity(DataFactory.randomFloat(5), DataFactory.randomInt(100), DataFactory.randomInt(100))
    }


    fun makeRating(): BookRating {
        return BookRating(DataFactory.randomFloat(5), DataFactory.randomInt(100), DataFactory.randomInt(100))
    }

}