package com.arty.cache.fake

import com.arty.cache.model.CachedBook
import com.arty.cache.model.CachedRating
import com.arty.data.model.BookEntity

object BookDataFactory {

    fun makeBook(isLiked: Boolean): CachedBook {
        return CachedBook(
            DataFactory.randomUuid(),
            DataFactory.randomUuid(),
            DataFactory.randomUuid(),
            makeRating(), DataFactory.randomUuid(),
            DataFactory.randomUuid(), DataFactory.randomUuid(),
            isLiked)
    }

    private fun makeRating(): CachedRating {
        return CachedRating(DataFactory.randomFloat(), DataFactory.randomInt(), DataFactory.randomInt())
    }

    fun makeBookEntity(authorsNum: Int): BookEntity {
        return BookEntity(
            DataFactory.randomUuid(),
            DataFactory.randomUuid(),
            DataFactory.randomUuid(),
            AuthorFactory.makeAuthorEntityList(authorsNum), RatingFactory.makeRatingEntity(),
            DataFactory.randomUuid(),
            DataFactory.randomUuid(),
            DataFactory.randomUuid(),
            DataFactory.randomBoolean())
    }

    fun makeLikedBookEntity(authorsNum: Int): BookEntity {
        return makeBookEntity(authorsNum).copy(isLiked = true)
    }

    fun makeNotLikedBookEntity(authorsNum: Int): BookEntity {
        return makeBookEntity(authorsNum).copy(isLiked = false)
    }

}