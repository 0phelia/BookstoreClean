package com.arty.cache.db

import android.arch.persistence.room.Database
import android.arch.persistence.room.RoomDatabase
import com.arty.cache.dao.CachedBooksDao
import com.arty.cache.dao.ConfigDao
import com.arty.cache.model.BookAuthorJoin
import com.arty.cache.model.CachedAuthor
import com.arty.cache.model.CachedBook
import com.arty.cache.model.Config
import javax.inject.Inject

@Database(entities = [CachedBook::class, CachedAuthor::class, BookAuthorJoin::class, Config::class], version = 1, exportSchema = false)
abstract class BookDatabase @Inject constructor(): RoomDatabase() {

    abstract fun cachedBooksDao(): CachedBooksDao

    abstract fun configDao(): ConfigDao

    companion object {

        //private var INSTANCE: BookDatabase? = null
        //private val lock = Any()
//
        //fun getInstance(context: Context): BookDatabase {
        //    if (INSTANCE == null) {
        //        synchronized(lock) {
        //            if (INSTANCE == null) {
        //                INSTANCE = Room.databaseBuilder(context.applicationContext,
        //                    BookDatabase::class.java, "books.db")
        //                    .build()
        //            }
        //            return INSTANCE as BookDatabase
        //        }
        //    }
        //    return INSTANCE as BookDatabase
        //}

    }


}