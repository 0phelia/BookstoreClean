package com.arty.cache.model

import android.arch.persistence.room.ColumnInfo
import android.arch.persistence.room.Embedded
import android.arch.persistence.room.Entity
import android.arch.persistence.room.PrimaryKey

@Entity(tableName = "books")
data class CachedBook(
    @PrimaryKey var id: String,
    var title: String,
    var description: String,
    @Embedded var rating: CachedRating,
    var coverImage: String,
    var datePublished: String,
    val publisher: String,
    @ColumnInfo(name = "is_liked")
    var isLiked: Boolean
)
