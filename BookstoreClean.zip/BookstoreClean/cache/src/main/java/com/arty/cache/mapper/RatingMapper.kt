package com.arty.cache.mapper

import com.arty.data.model.BookRatingEntity
import com.arty.cache.model.BookQueryResult
import com.arty.cache.model.CachedRating

class RatingMapper : Mapper<BookQueryResult, BookRatingEntity, CachedRating> {

    override fun mapQueryResultToEntity(type: BookQueryResult): BookRatingEntity {
        return BookRatingEntity(type.rating, type.ratingsGiven, type.reviewsGiven)
    }

    override fun mapEntityToModelsBundle(type: BookRatingEntity): CachedRating {
        return CachedRating(type.rating, type.ratingsGiven, type.reviewsGiven)
    }

}
