package com.arty.cache.model

import android.arch.persistence.room.ColumnInfo

data class BookQueryResult(
    var id: String,
    var title: String,
    var description: String,
    var authors: String,
    var rating: Float,
    var ratingsGiven: Int,
    var reviewsGiven: Int,
    var coverImage: String,
    var datePublished: String,
    val publisher: String,
    @ColumnInfo(name = "is_liked")
    var is_liked: Boolean
)
