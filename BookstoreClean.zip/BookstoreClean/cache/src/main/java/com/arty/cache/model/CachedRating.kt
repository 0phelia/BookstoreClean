package com.arty.cache.model

data class CachedRating(val rating: Float,
                        val ratingsGiven: Int,
                        val reviewsGiven: Int)