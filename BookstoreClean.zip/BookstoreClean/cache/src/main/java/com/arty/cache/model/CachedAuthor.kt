package com.arty.cache.model

import android.arch.persistence.room.Entity
import android.arch.persistence.room.PrimaryKey

@Entity(tableName = "authors")
data class CachedAuthor(
    @PrimaryKey
    var id: String,
    var name: String
)