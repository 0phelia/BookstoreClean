package com.arty.cache.db

object ConfigConstants {

    const val TABLE_NAME = "config"

    const val QUERY_CONFIG = "SELECT * FROM $TABLE_NAME"

}