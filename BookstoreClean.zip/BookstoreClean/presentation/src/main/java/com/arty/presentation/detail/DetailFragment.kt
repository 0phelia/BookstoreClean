package com.arty.presentation.detail

import android.arch.lifecycle.Observer
import android.arch.lifecycle.ViewModelProviders
import android.content.Context
import android.databinding.DataBindingUtil
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.arty.presentation.CLICKED_BOOK_ID
import com.arty.presentation.R
import com.arty.presentation.TRANSITION_NAME
import com.arty.presentation.di.ViewModelFactory
import dagger.android.support.AndroidSupportInjection
import javax.inject.Inject


class DetailFragment : AnimatedBaseFragment() {

    // ViewModel stuff
    @Inject
    lateinit var viewModelFactory: ViewModelFactory
    private lateinit var detailViewModel: DetailViewModel

    // UI stuff
    private lateinit var binding: com.arty.presentation.databinding.FragmentDetailBinding

    override fun onAttach(context: Context?) {
        super.onAttach(context)
        AndroidSupportInjection.inject(this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        detailViewModel = ViewModelProviders.of(this, viewModelFactory).get(DetailViewModel::class.java)
        val bookId = arguments?.getString(CLICKED_BOOK_ID)

        detailViewModel.getBook(bookId!!)
        detailViewModel.liveData.observe(this, Observer { bookRes ->
            bookRes?.data?.let {
                binding.bookDetailView = it
            }
        })
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_detail, container, false)
        binding.lifecycleOwner = this
        binding.viewModel = detailViewModel
        binding.simpleTransitionName = arguments?.getString(TRANSITION_NAME)




        //binding.btnLikeBook.setOnClickListener {
        //    val anim = AnimationUtils.loadAnimation(activity, R.anim.anim_btn_bounce)
        //    binding.btnLikeBook.startAnimation(anim)
        //    binding.viewmodel?.likeBook()
        //}

        return binding.root
    }

    override var viewsToSlideFromRight: List<Int> = listOf()
        get() = listOf(R.id.tv_book_title, R.id.tv_book_author, R.id.tv_book_price, R.id.rating_book)

    override var viewsToFade: List<Int> = listOf()
        get() = listOf(R.id.tv_book_pages_count, R.id.btn_buy_book, R.id.btn_like_book, R.id.scroll_description_holder)

    override var viewsToSlideFromBottom: List<Int> = listOf()
        get() = listOf(R.id.scroll_description_holder)

}
