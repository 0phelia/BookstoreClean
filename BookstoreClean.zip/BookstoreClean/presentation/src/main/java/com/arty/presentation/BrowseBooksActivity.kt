package com.arty.presentation

import android.arch.lifecycle.Observer
import android.arch.lifecycle.ViewModelProviders
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.util.Log
import com.arty.presentation.di.ViewModelFactory
import com.arty.presentation.favourites.BrowseBooksViewModel
import dagger.android.AndroidInjection
import javax.inject.Inject

class BrowseBooksActivity : AppCompatActivity() {

    @Inject lateinit var viewModelFactory: ViewModelFactory
    private lateinit var browseBooksViewModel: BrowseBooksViewModel


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_browse_books)
        AndroidInjection.inject(this)




        browseBooksViewModel = ViewModelProviders
            .of(this, viewModelFactory)
            .get(BrowseBooksViewModel::class.java)
        browseBooksViewModel.liveData.observe(this, Observer {
            Log.d("0phelia", " - - - - - - - - - - - - - -  ${it?.data}")
        })
        Log.d("0phelia", " - - - - - - - - - - - - - -  df" )
    }


    override fun onResume() {
        super.onResume()
        browseBooksViewModel.fetchBooks()
    }
}
