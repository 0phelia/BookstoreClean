package com.arty.presentation.di.module

import com.arty.presentation.BrowseBooksActivity
import com.arty.presentation.detail.DetailFragment
import com.arty.presentation.favourites.FavouritesFragment
import dagger.Module
import dagger.android.ContributesAndroidInjector

@Module
abstract class UiModule {

    @ContributesAndroidInjector
    abstract fun contibuteBrowseBooksActivity(): BrowseBooksActivity

    @ContributesAndroidInjector
    abstract fun contibuteFavouritesFragment(): FavouritesFragment

    @ContributesAndroidInjector
    abstract fun contibuteDetailsFragment(): DetailFragment

}