package com.arty.presentation.binders

import android.databinding.BindingAdapter
import android.view.View
import android.widget.ImageView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions

object CustomImageBinder {

    @BindingAdapter("customImageUrl")
    @JvmStatic
    fun loadCustomImageUrl(imageView: ImageView, url: String) {
        val options = RequestOptions()
        Glide.with(imageView.context).load(url).apply(options).into(imageView)
    }

    @BindingAdapter("customViewVisible")
    @JvmStatic
    fun setCustomViewVisible(view: View, isVisible: Boolean?) {
        view.visibility = if (isVisible == true) View.VISIBLE else View.GONE
    }


}