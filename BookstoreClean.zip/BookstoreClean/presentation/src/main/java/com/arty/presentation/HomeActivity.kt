package com.arty.presentation

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.os.Build
import android.os.Bundle
import android.support.transition.TransitionInflater
import android.support.v4.app.Fragment
import android.support.v4.view.GravityCompat
import android.support.v4.widget.DrawerLayout
import android.support.v7.app.ActionBarDrawerToggle
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.Toolbar
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.animation.DecelerateInterpolator
import com.arty.presentation.detail.DetailFragment
import com.arty.presentation.favourites.FavouritesFragment

const val TRANSITION_NAME = "TRANSITION_NAME"
const val CLICKED_BOOK_ID = "CLICKED_BOOK_ID"
const val TAG = "DETAIL_FRAGMENT_TAG"

class HomeActivity : AppCompatActivity() {

    // UI stuff
    private lateinit var drawer: DrawerLayout
    private lateinit var toolbar: Toolbar
    private lateinit var drawerToggle: ActionBarDrawerToggle
    private lateinit var firstFragment: FavouritesFragment



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        setupActionBar()
        setupView(savedInstanceState)
    }


    private fun setupView(savedInstanceState: Bundle?) {
        if (findViewById<View>(R.id.home_fragment_container) != null) {
            if (savedInstanceState != null) return

            firstFragment = FavouritesFragment()
            firstFragment.arguments = intent.extras
            supportFragmentManager.beginTransaction()
                    .add(R.id.home_fragment_container, firstFragment)
                    .commit()
        }
    }



    private fun setupActionBar() {
        supportActionBar?.elevation = 0f
        supportActionBar?.setHomeButtonEnabled(true)

        // setting up drawer
        toolbar =  findViewById(R.id.toolbar)
        drawer =  findViewById(R.id.drawer_layout)
        setSupportActionBar(toolbar)
        drawerToggle = ActionBarDrawerToggle(this, drawer, toolbar, R.string.drawer_open, R.string.drawer_close)
        drawer.addDrawerListener(drawerToggle)
        drawerToggle.syncState()
    }

    override fun onOptionsItemSelected( item: MenuItem):Boolean {
        if (drawerToggle.onOptionsItemSelected(item)) {
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    private var mToolBarNavigationListenerIsRegistered: Boolean = false

    private fun enableViews(enable: Boolean) {
        if (enable) {
            drawer.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED)
            animateHamburgerIcon(true)
            if (!mToolBarNavigationListenerIsRegistered) {
                drawerToggle.setToolbarNavigationClickListener { onBackPressed() }
                mToolBarNavigationListenerIsRegistered = true
            }

        } else {
            drawer.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED)
            animateHamburgerIcon(false)
            drawerToggle.setToolbarNavigationClickListener(null)
            mToolBarNavigationListenerIsRegistered = false
        }

    }

    protected fun animateHamburgerIcon(isHomeAsUp: Boolean) {
            val anim = if (isHomeAsUp) ValueAnimator.ofFloat(0f, 1f) else ValueAnimator.ofFloat(1f, 0f)
            anim.addUpdateListener { valueAnimator ->
                val slideOffset = valueAnimator.animatedValue as Float
                drawerToggle.onDrawerSlide(drawer, slideOffset)
            }

            //override fun onAnimationEnd(animation: Animator?) {
            //   // if (isHomeAsUp) {
            //   //     drawerToggle.setDrawerIndicatorEnabled(false)
            //   //     supportActionBar!!.setDisplayHomeAsUpEnabled(true)
            //   // } else {
            //   //     supportActionBar!!.setDisplayHomeAsUpEnabled(false)
            //   //     drawerToggle.setDrawerIndicatorEnabled(true)
            //   // }
            //}

            anim.interpolator = DecelerateInterpolator()
            anim.duration = 500
            anim.start()
    }

    override fun onBackPressed() {
        if (drawer.isDrawerOpen(GravityCompat.START))
            drawer.closeDrawer(GravityCompat.START)
        else if (supportFragmentManager.backStackEntryCount > 0) {
            enableViews(false)
            supportFragmentManager.popBackStack()
        }
        else
            super.onBackPressed()
    }

    fun openDetailFragment(bookId: String, transitionName: String, sharedView: View) {
        val detailFragment = DetailFragment()
        Bundle().apply {
            putString(CLICKED_BOOK_ID, bookId)
            putString(TRANSITION_NAME, transitionName)
            detailFragment.arguments = this
        }
        setTransitions(firstFragment, detailFragment)
        openDetailFragment(transitionName, detailFragment, sharedView)
        enableViews(true)
    }

    val TAG = "ASDFasdf"
    private fun openDetailFragment(transitionName: String, fragment: Fragment, sharedView: View) {
        supportFragmentManager.beginTransaction()
            .addSharedElement(sharedView, transitionName)
            .addToBackStack(TAG)
            .replace(R.id.home_fragment_container, fragment)
            .commit()
    }

    @SuppressLint("ObsoleteSdkInt")
    private fun setTransitions(source: FavouritesFragment, dest: DetailFragment) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            TransitionInflater
                    .from(this)
                    .inflateTransition(R.transition.book_cover_simple_transition)
                    .let {
                        source.sharedElementReturnTransition = it
                        dest.sharedElementEnterTransition = it
            }

            dest.allowEnterTransitionOverlap = true
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu, menu)
        return true
    }
}
