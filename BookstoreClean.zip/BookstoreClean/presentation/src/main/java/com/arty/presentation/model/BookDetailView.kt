package com.arty.presentation.model

data class BookDetailView(val id: String, val title: String, val description: String,
                    val authors: String,
                    val rating: Float,
                    val coverImage: String,
                    val datePublished: String,
                    val publisher: String,
                          val parsedPrice: String, // TODO delete && replace placeholder in UI with smth else
                          val pages: Int,           // TODO delete && replace placeholder in UI with smth else
                    val isLiked: Boolean)