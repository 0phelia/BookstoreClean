package com.arty.presentation.di.module

import android.arch.persistence.room.Room
import android.content.Context
import com.arty.cache.BooksCacheImpl
import com.arty.cache.db.BookDatabase
import com.arty.cache.mapper.AuthorMapper
import com.arty.cache.mapper.BookMapper
import com.arty.cache.mapper.RatingMapper
import com.arty.data.repository.BooksCache
import dagger.Module
import dagger.Provides


@Module
class CacheModule {

    //@Provides
    //fun provideApp(application: Application): Application {
    //    return application
    //}
    //constructor(application: Application)
    //@Module
   //companion object {
   //    @JvmStatic
   //}

    @Provides
    fun provideDatabase(context: Context): BookDatabase {
       return  Room.databaseBuilder(context,
           BookDatabase::class.java, "books.db")
           .build()
        //return BookDatabase.getInstance(application)
    }

    @Provides
    fun provideAuthorMapper(): AuthorMapper {
        return AuthorMapper()
    }

    @Provides
    fun provideRatingMapper(): RatingMapper {
        return RatingMapper()
    }

    @Provides
    fun provideBookMapper(authorMapper: AuthorMapper, ratingMapper: RatingMapper): BookMapper {
        return BookMapper(authorMapper, ratingMapper)
    }

    @Provides
    fun provideBookCache(db: BookDatabase, mapper: BookMapper): BooksCache {
        return BooksCacheImpl(db, mapper)
    }
}