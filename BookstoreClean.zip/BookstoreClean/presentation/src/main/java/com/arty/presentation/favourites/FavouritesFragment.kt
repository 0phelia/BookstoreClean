package com.arty.presentation.favourites

import android.arch.lifecycle.Observer
import android.arch.lifecycle.ViewModelProviders
import android.content.Context
import android.databinding.DataBindingUtil
import android.os.Bundle
import android.support.constraint.ConstraintLayout
import android.support.v4.app.Fragment
import android.support.v7.widget.GridLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.arty.presentation.HomeActivity
import com.arty.presentation.R
import com.arty.presentation.di.ViewModelFactory
import dagger.android.support.AndroidSupportInjection
import javax.inject.Inject

class FavouritesFragment : Fragment() {

    // ViewModel stuff
    @Inject lateinit var viewModelFactory: ViewModelFactory
    private lateinit var browseBooksViewModel: BrowseBooksViewModel

    // UI stuff
    private lateinit var lm: RecyclerView.LayoutManager
    private lateinit var adapter: FavouritesListAdapter

    override fun onAttach(context: Context?) {
        super.onAttach(context)
        AndroidSupportInjection.inject(this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        browseBooksViewModel = ViewModelProviders.of(this, viewModelFactory).get(BrowseBooksViewModel::class.java)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {

        val binding: com.arty.presentation.databinding.FragmentFavouritesBinding = DataBindingUtil
                .inflate(inflater, R.layout.fragment_favourites, container, false)

        binding.viewmodel = browseBooksViewModel
        binding.lifecycleOwner = this // TODO do research on that!!!

         adapter = FavouritesListAdapter(
            View.OnClickListener { clickedView ->
                val itemPosition = binding.rvFavourites.getChildLayoutPosition(clickedView)
                val item = adapter.getItem(itemPosition)
                val sharedView = (lm.findViewByPosition(itemPosition) as ConstraintLayout).getChildAt(0)
                //Toast.makeText(this.context, item.title, Toast.LENGTH_SHORT).show()

                (activity as HomeActivity).openDetailFragment(item.id, "transition_${item.id}", sharedView)
            }
        )

        subscribeUi(adapter)

        // intermediary var is necessary to circumvent 'already attached' xception
        lm = GridLayoutManager(activity, 3)
        binding.rvFavourites.layoutManager = lm
        binding.rvFavourites.adapter = binding.rvFavourites.adapter ?: adapter

        return binding.root
    }


    private fun subscribeUi(adapter: FavouritesListAdapter) {
        browseBooksViewModel.liveData.observe(this, Observer { booksRes ->
            booksRes?.data?.let {
                adapter.updateFavorites(it)
            }
        })
    }


    /**
     *      set up toolbar elevation animation (see animator/toolbar_anim.xml)
     */
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        //val rv = view.findViewById<RecyclerView>(R.id.rv_favourites)

        browseBooksViewModel.fetchBooks()

        // TODO fix toolbar
        //val tb = activity!!.findViewById<Toolbar>(R.id.toolbar)
        //rv.viewTreeObserver.addOnScrollChangedListener {
        //    tb?.isSelected = rv.canScrollVertically(-1)
        //}
    }

}
