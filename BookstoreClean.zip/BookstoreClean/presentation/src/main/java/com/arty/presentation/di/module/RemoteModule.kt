package com.arty.presentation.di.module

import com.arty.cache.BuildConfig
import com.arty.data.repository.BooksRemote
import com.arty.remote.BooksRemoteImpl
import com.arty.remote.service.GoogleBooksService
import com.arty.remote.service.NYTimesBookListFactoryServiceFactory
import com.arty.remote.service.NYTimesBookListsService
import dagger.Binds
import dagger.Module
import dagger.Provides

@Module
abstract class RemoteModule {

    @Module
    companion object {
        @Provides
        @JvmStatic
        fun provideGithubService(): GoogleBooksService {
            return NYTimesBookListFactoryServiceFactory.makeGoogleBooksService(BuildConfig.DEBUG)
        }

        @Provides
        @JvmStatic
        fun provideGithubService2(): NYTimesBookListsService {
            return NYTimesBookListFactoryServiceFactory.makeNYTimesBookListsService(BuildConfig.DEBUG)
        }
    }

    @Binds
    abstract fun bindBooksRemote(booksRemote: BooksRemoteImpl): BooksRemote
}