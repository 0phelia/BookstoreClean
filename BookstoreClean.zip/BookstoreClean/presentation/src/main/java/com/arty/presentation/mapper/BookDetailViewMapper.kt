package com.arty.presentation.mapper

import com.arty.domain.model.Book
import com.arty.domain.model.BookAuthor
import com.arty.presentation.model.BookDetailView
import java.text.NumberFormat
import java.util.*
import javax.inject.Inject

class BookDetailViewMapper  @Inject constructor(): Mapper<Book, BookDetailView> {
    override fun mapToView(type: Book): BookDetailView {
        return with(type) {
            BookDetailView(id, title, description, mapAuthors(authors), rating.rating, getCoverImage(coverImage), datePublished, publisher, parsePriceToUsd(100.3f), 133, isLiked)
        }
    }

    private fun getCoverImage(coverImage: String?): String {
        return coverImage ?: "http://danikadinsmore.com/wp-content/uploads/2017/06/placeholder-cover-1.jpg"
    }

    private fun mapAuthors(authors: List<BookAuthor>): String {
        return authors.joinToString { next ->
            next.name
        }
    }

    // TODO extract as delegate obj
    private fun parsePriceToUsd(price: Float): String = NumberFormat
        .getCurrencyInstance( Locale("en", "US"))
        .format(price)

}
