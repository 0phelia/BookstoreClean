package com.arty.presentation.state

enum class ResourceState {
    LOADING, SUCCESS, ERROR
}