package com.arty.presentation.favourites

import android.databinding.DataBindingUtil
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.arty.presentation.R
import com.arty.presentation.model.BookView

class FavouritesListAdapter(private var listener: View.OnClickListener) : RecyclerView.Adapter<FavouritesListAdapter.DataViewHolder>() {

    var data : List<BookView> = emptyList()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DataViewHolder {
        val itemBinding: com.arty.presentation.databinding.ItemFavouriteBinding = DataBindingUtil.inflate(LayoutInflater.from(parent.context),
                R.layout.item_favourite,
                parent,
                false)
        return DataViewHolder(itemBinding, listener)
    }

    override fun getItemCount() = data.size

    override fun onBindViewHolder(holder: DataViewHolder, position: Int) {
        holder.bind(position, data[position])
    }

    fun updateFavorites(books: List<BookView>) {
        data = books
        notifyDataSetChanged()
    }

    fun getItem(itemPosition: Int): BookView {
        return data[itemPosition]
    }


    class DataViewHolder(private val binding: com.arty.presentation.databinding.ItemFavouriteBinding,
                         listener: View.OnClickListener)
        : RecyclerView.ViewHolder(binding.root) {

        init {
            itemView.setOnClickListener(listener)
        }

        fun bind(position: Int, item: BookView) {
            binding.simpleTransitionName = "transition_$position"
            binding.book = item
            binding.executePendingBindings()
        }

    }

}