package com.arty.presentation.model

data class BookView(val id: String, val title: String, val description: String,
            val authors: String,
            val rating: Float,
            val coverImage: String,
            val datePublished: String,
            val publisher: String,
            val isLiked: Boolean)