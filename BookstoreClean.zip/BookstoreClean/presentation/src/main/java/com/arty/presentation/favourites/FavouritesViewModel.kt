package com.arty.presentation.favourites

import android.arch.lifecycle.ViewModel

class FavouritesViewModel: ViewModel() {


   //val offset = MutableLiveData<Int>()
   //val quantity = MutableLiveData<Int>()

   //var selected: LiveData<Book>
   //val booksResource: LiveData<Resource<List<Book>>>
   //var books: LiveData<List<Book>>
   //var isLoading: LiveData<Boolean>
   //var isError: LiveData<Boolean>

   //// calling UI specific things (navigation, alert dialogs, snack bars)
   //private val _navigateToDetails = MutableLiveData<Event<Int>>()
   //val navigateToDetails : LiveData<Event<Int>>
   //    get() = _navigateToDetails
   //fun navigateToDetails(itemId: Int) {
   //    _navigateToDetails.value = Event(itemId)
   //}

   //init {
   //    booksResource = Transformations
   //            .switchMap(offset) { offsetInt -> repository.getBooks(offsetInt, 10) }
   //    books = Transformations
   //            .map(booksResource) { resourceListBook -> resourceListBook.data}
   //    selected = Transformations
   //            .map(navigateToDetails) { it -> books.value!![it.peekContent()]}
   //    isLoading = Transformations
   //            .switchMap(booksResource) { resourceListBook -> extractLoading(resourceListBook)}
   //    isError = Transformations
   //            .switchMap(booksResource) { resourceListBook -> extractError(resourceListBook)}
   //    offset.value = 0
   //    quantity.value = 10
   //}

   //private fun extractError(resourceListBook: Resource<List<Book>>): LiveData<Boolean> {
   //    val result = MutableLiveData<Boolean>()
   //    result.value = resourceListBook.status == Resource.Status.ERROR
   //    return result
   //}

   //private fun extractLoading(resourceListBook: Resource<List<Book>>): LiveData<Boolean> {
   //    val result = MutableLiveData<Boolean>()
   //    result.value = resourceListBook.status == Resource.Status.LOADING
   //    return result
   //}

}