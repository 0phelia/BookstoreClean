package com.arty.presentation.model

data class BookRatingView(val rating: Float, val ratingsGiven: Int, val reviewsGiven: Int)

