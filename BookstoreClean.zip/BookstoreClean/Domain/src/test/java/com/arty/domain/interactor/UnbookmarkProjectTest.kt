package com.arty.domain.interactor

class UnbookmarkProjectTest {
   // lateinit var unbookmarkProject: UnbookmarkProject
   // @Mock
   // lateinit var projectsRepository: ProjectsRepository
   // @Mock
   // lateinit var postExecutionThread: PostExecutionThread
//
   // @Before
   // fun setup() {
   //     MockitoAnnotations.initMocks(this)
   //     unbookmarkProject = UnbookmarkProject(projectsRepository, postExecutionThread)
   // }
//
   // @Test
   // fun unbookmarkCompletes() {
   //     stubProjectRepository(Completable.complete())
   //     val testObservable = unbookmarkProject
   //         .buildUseCaseCompletable(UnbookmarkProject.Params(ProjectDataFactory.randomUuid())).test()
   //     testObservable.assertComplete()
   // }
//
   // private fun stubProjectRepository(completable: Completable) {
   //     whenever(projectsRepository.unbookmarkProject(any()))
   //         .thenReturn(completable)
   // }
}