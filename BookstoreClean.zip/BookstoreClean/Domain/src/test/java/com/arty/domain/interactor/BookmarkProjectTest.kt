package com.arty.domain.interactor

class BookmarkProjectTest {
   // lateinit var bookmarkProject: BookmarkProject
   // @Mock lateinit var projectsRepository: ProjectsRepository
   // @Mock lateinit var postExecutionThread: PostExecutionThread
//
   // @Before
   // fun setup() {
   //     MockitoAnnotations.initMocks(this)
   //     bookmarkProject = BookmarkProject(projectsRepository, postExecutionThread)
   // }
//
   // @Test
   // fun bookmarkCompletes() {
   //     stubBookmarkProject(Completable.complete())
   //     val testObserver = bookmarkProject
   //         .buildUseCaseCompletable(params = BookmarkProject.Params(ProjectDataFactory.randomUuid())).test()
   //     testObserver.assertComplete()
   // }
//
   // @Test(expected = IllegalArgumentException::class)
   // fun bookmarkExceptionThrown() {
   //     stubBookmarkProject(Completable.complete())
   //     val testObserver = bookmarkProject
   //         .buildUseCaseCompletable(params = null).test()
   // }
//
   // private fun stubBookmarkProject(completable: Completable) {
   //     whenever(projectsRepository.bookmarkProject(any()))
   //         .thenReturn(completable)
   // }
}
