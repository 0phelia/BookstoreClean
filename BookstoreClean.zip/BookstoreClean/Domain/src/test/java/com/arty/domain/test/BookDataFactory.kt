package com.arty.domain.test

import com.arty.domain.model.Book
import com.arty.domain.model.BookAuthor
import com.arty.domain.model.BookRating
import com.arty.domain.test.DataFactory.randomBoolean
import com.arty.domain.test.DataFactory.randomFloat
import com.arty.domain.test.DataFactory.randomInt
import com.arty.domain.test.DataFactory.randomUuid

object BookDataFactory {

    fun makeBook(): Book {
        return Book(randomUuid(), randomUuid(), randomUuid(),
            makeAuthorList(2), makeRating(),
            randomUuid(), randomUuid(), randomUuid(), randomBoolean())
    }

    fun makeBookList(count: Int): List<Book> {
        return mutableListOf<Book>().apply {
            repeat(count) {
                add(makeBook())
            }
        }
    }

    fun makeAuthorList(count: Int): List<BookAuthor> {
        return mutableListOf<BookAuthor>().apply {
            repeat(count) {
                add(makeAuthor())
            }
        }
    }

    fun makeAuthor(): BookAuthor {
        return BookAuthor(randomUuid(), randomUuid())
    }

    fun makeRating(): BookRating {
        return BookRating(randomFloat(5), randomInt(100), randomInt(100))
    }
}