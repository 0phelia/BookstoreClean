package com.arty.domain.model

class BookDetails {
}