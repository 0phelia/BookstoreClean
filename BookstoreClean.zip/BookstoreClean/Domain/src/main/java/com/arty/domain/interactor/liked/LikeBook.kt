package com.arty.domain.interactor.liked

import com.arty.domain.interactor.Result
import com.arty.domain.repository.BooksRepository
import javax.inject.Inject

open class LikeBook @Inject constructor(
    private val booksRepository: BooksRepository
) {
    companion object {
        const val DEFAULT_ERROR_MESSAGE = "Failed to like book"
    }

    suspend fun execute(bookId: String): Result<Nothing?> {
        return try {
            booksRepository.likeBook(bookId)
            Result.Success(null)
        } catch (e: Exception) {
            Result.Error(e.message, e)
        }
    }

}