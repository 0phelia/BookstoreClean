package com.arty.domain.interactor.comment

class CommentBook {
}