package com.arty.domain.model

class BookRating(val rating: Float, val ratingsGiven: Int, val reviewsGiven: Int) {

}
