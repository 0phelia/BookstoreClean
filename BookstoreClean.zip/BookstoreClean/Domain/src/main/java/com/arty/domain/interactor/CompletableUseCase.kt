package com.arty.domain.interactor

abstract class CompletableUseCase<Params, T> {

    protected abstract var useCaseFunction: (Params?) -> T

    open fun execute( params: Params? = null): Result<T> {
        return try {
            Result.Success(useCaseFunction.invoke(params))
        } catch (e: Exception) {
            Result.Error(e.message, e)
        }
    }

}