package com.arty.domain.model

class BookAuthor(val id: String, val name: String)
