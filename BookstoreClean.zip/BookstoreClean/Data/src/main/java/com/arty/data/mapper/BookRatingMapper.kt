package com.arty.data.mapper

import com.arty.data.model.BookRatingEntity
import com.arty.domain.model.BookRating
import javax.inject.Inject

open class BookRatingMapper @Inject constructor(): EntityMapper<BookRatingEntity, BookRating> {
    override fun mapToEntity(data: BookRating): BookRatingEntity {
        return BookRatingEntity(data.rating, data.ratingsGiven, data.reviewsGiven)
    }

    override fun mapFromEntity(entity: BookRatingEntity): BookRating {
        return BookRating(entity.rating, entity.ratingsGiven, entity.reviewsGiven)
    }
}