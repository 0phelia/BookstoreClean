package com.arty.data.model

class GoogleBookEntity(
    val title: String,
    val authors: List<String>,
    val publishedDate: String,
    val description: String?,
    val pageCount: Int,
    val averageRating: Float,
    val ratingsCount: Int,
    val coverSmall: String,
    val coverMedium: String
) {

}
