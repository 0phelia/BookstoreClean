package com.arty.data.model

data class BookRatingEntity(val rating: Float, val ratingsGiven: Int, val reviewsGiven: Int) {

}
