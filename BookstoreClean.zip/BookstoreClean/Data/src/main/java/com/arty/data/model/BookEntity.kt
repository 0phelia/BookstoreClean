package com.arty.data.model

data class BookEntity(val id: String, val title: String, val description: String,
                 val authors: List<BookAuthorEntity>,
                 val rating: BookRatingEntity,
                 val coverImage: String?,
                 val datePublished: String, val publisher: String,
                 val isLiked: Boolean = false) {
}