package com.arty.data.mapper

import com.arty.data.model.BookRatingEntity
import com.arty.data.test.factory.RatingFactory
import com.arty.domain.model.BookRating
import org.junit.Test
import org.junit.runner.RunWith
import org.junit.runners.JUnit4
import kotlin.test.assertEquals


@RunWith(JUnit4::class)
class RatingMapperTest {
    private val mapper = BookRatingMapper()

    @Test
    fun mapFromEntityMapsData() {
        val entity = RatingFactory.makeRatingEntity()
        val model = mapper.mapFromEntity(entity)

        assertEqualData(entity, model)
    }

    @Test
    fun mapToEntityMapsData() {
        val model = RatingFactory.makeRating()
        val entity = mapper.mapToEntity(model)

        assertEqualData(entity, model)
    }

    private fun assertEqualData(entity: BookRatingEntity,
                                model: BookRating
    ) {
        assertEquals(entity.rating, model.rating)
        assertEquals(entity.ratingsGiven, model.ratingsGiven)
        assertEquals(entity.reviewsGiven, model.reviewsGiven)
    }

}


