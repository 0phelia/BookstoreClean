package com.arty.data.test.factory

import com.arty.data.model.BookEntity
import com.arty.data.test.factory.AuthorFactory.makeAuthorEntityList
import com.arty.data.test.factory.AuthorFactory.makeAuthorList
import com.arty.data.test.factory.RatingFactory.makeRating
import com.arty.data.test.factory.RatingFactory.makeRatingEntity
import com.arty.domain.model.Book


object BookFactory {
    fun makeBookEntity(): BookEntity {
        return BookEntity(DataFactory.randomString(),
            DataFactory.randomString(), DataFactory.randomString(),
            makeAuthorEntityList(2), makeRatingEntity(),
            DataFactory.randomString(), DataFactory.randomString(),
            DataFactory.randomString(),
            DataFactory.randomBoolean())
    }

    fun makeBook(): Book {
        return Book(
            DataFactory.randomString(),
            DataFactory.randomString(),
            DataFactory.randomString(),
            makeAuthorList(2),
            makeRating(),
            DataFactory.randomString(),
            DataFactory.randomString(),
            DataFactory.randomString(),
            DataFactory.randomBoolean()
        )
    }


}