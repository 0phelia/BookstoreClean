package com.arty.remote.model.google

import com.google.gson.annotations.SerializedName

class GoogleBookModel(
    @SerializedName("id") val id: String,
    @SerializedName("volumeInfo") val volumeInfo: GoogleBooksVolumeInfoModel) {
}
