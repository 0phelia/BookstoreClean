package com.arty.remote.model.google

import com.google.gson.annotations.SerializedName

class GoogleBookImageLinksModel(
    @SerializedName("smallThumbnail") val smallThumbnail: String,
    @SerializedName("thumbnail") val thumbnail: String
 )
