package com.arty.remote.model.nytimes

import com.google.gson.annotations.SerializedName

class BookListModel(
    @SerializedName("status") val status: String,
    @SerializedName("num_results") val numResults: Int,
    @SerializedName("last_modified") val lastModified: String,
    @SerializedName("results") val results: List<BookModel>) {
}