package com.arty.remote

import com.arty.data.model.GoogleBookEntity
import com.arty.data.model.NytBookEntity
import com.arty.data.repository.BooksRemote
import com.arty.remote.mapper.GoogleResponseMapper
import com.arty.remote.mapper.NytBooksModelMapper
import com.arty.remote.service.GoogleBooksService
import com.arty.remote.service.NYTimesBookListsService
import javax.inject.Inject

class BooksRemoteImpl @Inject constructor(
    private val nytimesService: NYTimesBookListsService,
    private val googleService: GoogleBooksService,
    private val nytModelMapper: NytBooksModelMapper,
    private val googleResponseMapper: GoogleResponseMapper
): BooksRemote {

    override suspend fun getNYTimesBooks(listName: String): List<NytBookEntity> {
        val nytBooks = nytimesService
            .getBookList(listName,"An35k3sU7BGIYvzTqk7qRlbp7TT3ozhK").await()
        return nytModelMapper.mapFromModel(nytBooks)
    }

    override suspend fun getGoogleBooks(isbn13: String): List<GoogleBookEntity>? {
        val googleBookDetails = googleService
            .getBookDetails(isbn13,"AIzaSyAcotR8YZ-Zsd6dcREUBhkUA_NE3UC5AIY").await()
        return googleResponseMapper.mapFromModel(googleBookDetails)
    }

}