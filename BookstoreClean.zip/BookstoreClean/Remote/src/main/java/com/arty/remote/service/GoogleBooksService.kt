package com.arty.remote.service

import com.arty.remote.model.google.GoogleBooksResponseModel
import kotlinx.coroutines.Deferred
import retrofit2.http.GET
import retrofit2.http.Query

interface GoogleBooksService {
    @GET("books/v1/volumes")
    fun getBookDetails(
        @Query("q") isbn: String,
        //@Path("isbn") isbn: String,
        //@Path("isbn") isbn: String,
        @Query("key") apiKey: String
    ): Deferred<GoogleBooksResponseModel>
}