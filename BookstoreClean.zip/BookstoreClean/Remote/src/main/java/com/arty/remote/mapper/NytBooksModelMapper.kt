package com.arty.remote.mapper

import com.arty.data.model.BookRatingEntity
import com.arty.data.model.NytBookEntity
import com.arty.remote.model.nytimes.BookListModel
import javax.inject.Inject

/**
 * rating & datePublished are empty!!!
 */
open class NytBooksModelMapper @Inject constructor() :
    ModelMapper<BookListModel, List<NytBookEntity>> {

    override fun mapFromModel(model: BookListModel): List<NytBookEntity> {
        return model.results.map { book ->
            with(book.bookDetails[0]) {
                NytBookEntity(title, description, author, getEmptyRating(), primary_isbn10, primary_isbn13, getEmptyDatePublished(), publisher)
            }
        }
    }

    private fun getEmptyDatePublished(): String {
        return ""
    }

    private fun getEmptyRating(): BookRatingEntity {
        return BookRatingEntity(0f, 0, 0)
    }

}
