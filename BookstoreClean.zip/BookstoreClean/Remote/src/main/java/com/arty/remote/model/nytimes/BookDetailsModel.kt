package com.arty.remote.model.nytimes

import com.google.gson.annotations.SerializedName

class BookDetailsModel(
    val id: String,
    @SerializedName("title") val title: String,
    @SerializedName("description") val description: String,
    @SerializedName("contributor") val contributor: String,
    @SerializedName("author") val author: String,
    @SerializedName("contributor_note") val contributor_note: String,
    @SerializedName("publisher") val publisher: String,
    @SerializedName("primary_isbn13") val primary_isbn13: String,
    @SerializedName("primary_isbn10") val primary_isbn10: String
)


