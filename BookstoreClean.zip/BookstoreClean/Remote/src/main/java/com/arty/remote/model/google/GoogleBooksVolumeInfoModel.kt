package com.arty.remote.model.google

import com.google.gson.annotations.SerializedName

class GoogleBooksVolumeInfoModel(
    @SerializedName("title") val title: String,
    @SerializedName("authors") val authors: List<String>?,
    @SerializedName("publishedDate") val publishedDate: String?,
    @SerializedName("description") val description: String?,
    @SerializedName("pageCount") val pageCount: Int,

    @SerializedName("averageRating") val averageRating: Float,
    @SerializedName("ratingsCount") val ratingsCount: Int,

    @SerializedName("imageLinks") val imageLinks: GoogleBookImageLinksModel
)