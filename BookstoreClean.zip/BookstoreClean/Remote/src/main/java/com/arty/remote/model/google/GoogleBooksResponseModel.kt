package com.arty.remote.model.google

import com.google.gson.annotations.SerializedName

class GoogleBooksResponseModel(
    @SerializedName("kind") val kind: String,
    @SerializedName("totalItems") val totalItems: Int,
    @SerializedName("items") val items: List<GoogleBookModel>?
)

