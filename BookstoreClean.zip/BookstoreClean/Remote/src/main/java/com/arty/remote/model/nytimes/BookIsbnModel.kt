package com.arty.remote.model.nytimes

import com.google.gson.annotations.SerializedName

class BookIsbnModel(
    @SerializedName("isbn10") val isbn10: String,
    @SerializedName("isbn13") val isbn13: String) {
}

